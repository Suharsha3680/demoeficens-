#! /bin/bash

ls
EXIT_STATUS=$?
echo "This script will exit with a 0 exit status.--> ${EXIT_STATUS}"